put sim_main executable in the same directory as test.sh and tests directory

chmod +x ./sim_main ./test.sh
run ./test.sh
